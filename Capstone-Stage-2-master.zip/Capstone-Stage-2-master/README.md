[![Build Status](https://travis-ci.com/saurabhjn76/Capstone-Stage-2.svg?token=9zLsxUscFwE71GQT5Us9&branch=master)](https://travis-ci.com/saurabhjn76/Capstone-Stage-2)

# Capstone-Stage-2
General knowledge quest

## Sign-keys
*Temporary sign keys are stored in [signconfig](https://file.town/download/jr1010r86pc8ustrrfvy8dx9d) directory.
*The database is android.jks
 *Database password is 'password', Key alias is 'MYKEY' and key's password is 'password'.
 
 ## Sample username and password
 
 email-saurabh@gmail.com
 password-123456
 
